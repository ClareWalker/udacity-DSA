"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 4:
The telephone company want to identify numbers that might be doing
telephone marketing. Create a set of possible telemarketers:
these are numbers that make outgoing calls but never send texts,
receive texts or receive incoming calls.

Print a message:
"These numbers could be telemarketers: "
<list of numbers>
The list of numbers should be print out one per line in lexicographic order with no duplicates.
"""

possible_telemarketer = []
not_telemarketer = []

for calling, receiving, _, _ in calls:
    if calling not in possible_telemarketer:
        possible_telemarketer += [calling]

    if receiving not in not_telemarketer:
        not_telemarketer += [receiving]

for texting, receiving, _ in texts:
    for number in texting, receiving:
        if number not in not_telemarketer:
            not_telemarketer += [number]

telemarketers = []
for number in possible_telemarketer:
    if number not in not_telemarketer:
        telemarketers += [number]

telemarketers.sort()
print("These numbers could be telemarketers: ")
for number in telemarketers:
    print(number)